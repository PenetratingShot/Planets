# frozen_string_literal: true
module Gem::Resolver::Molinillo
  # The version of Gem::Resolver::Molinillo.
  VERSION = '0.4.1'.freeze
end
